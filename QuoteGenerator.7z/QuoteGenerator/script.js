function newQuote(){

let bg= document.getElementById('btn');
let quotes=['Be yourself; everyone else is already taken.','So many books, so little time.','Two things are infinite: the universe and human stupidity; and Im not sure about the universe.',
'A room without books is like a body without a soul.'];

const dis=parseInt(Math.random()*quotes.length);
document.getElementById('displayQuote').innerHTML=quotes[dis];


}