rojectName: Random quotes using JS

Description: This random quotes generator project will help user to generate a random quote. A button will be displayed at the center , clicking on which a new quote will be displayed on screen.

Solution approach: 

1. HTML file: Giving a meaningful heading and a button at the center.
2. JS file: Creating a function . Craetes an array of different quotes. Parse through the array, and return a random qupte whenever the button is clicked.